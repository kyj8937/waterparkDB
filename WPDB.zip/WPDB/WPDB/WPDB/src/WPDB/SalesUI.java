package WPDB;

import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;

public class SalesUI {
    private static JTable table;

    public static void showSalesUI(DBConnector db) throws SQLException {    	
    	JFrame frame = new JFrame("매출 검색");
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());

        topPanel.add(new JLabel("날짜 검색 : "));
        JTextField monthTextField = new JTextField(10);
        topPanel.add(monthTextField);
        topPanel.add(new JLabel("월"));

        JButton searchButton = new JButton("검색");
        topPanel.add(searchButton);

        searchButton.addActionListener(e -> {
        	 String selectedMonth = monthTextField.getText();

             try {
                 // 수정된 메서드 호출
                 showSalesDataForMonth(db, selectedMonth);
             } catch (SQLException e1) {
                 e1.printStackTrace();
             }
        });

        panel.add(topPanel, BorderLayout.NORTH);

        String[] columns = {"지점", "총액", "관리자아이디"};
        DefaultTableModel model = new DefaultTableModel(null, columns);
        table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // showAllSalesData(db);

        frame.getContentPane().add(panel);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);

        frame.setVisible(true);
    }

    private static void showSalesDataForMonth(DBConnector db, String selectedMonth) throws SQLException {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        
        List<Object[]> resultList = db.sqlRun_Sales(selectedMonth);
        
        for (Object[] row : resultList) {
            model.addRow(new Object[]{(String)row[0], (int)row[1], (String)row[2]});
        }
    }

    public static void main(String[] args) {
        DBConnector db = new DBConnector();
        db.DB_load();
    	SwingUtilities.invokeLater(() -> {
			try {
				showSalesUI(db);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
    }
}
