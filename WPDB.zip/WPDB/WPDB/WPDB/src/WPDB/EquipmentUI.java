package WPDB;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class EquipmentUI {
    private static JTable table;
    private static JComboBox<String> equipmentNameComboBox;
    private static JComboBox<String> sizeComboBox;
    private static JTextField branchSearchField;
    private static DefaultTableModel originalTableModel;

    public static void showEquipmentUI(DBConnector db) {
        JFrame frame = new JFrame("장비 검색");
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());

        branchSearchField = new JTextField(15);
        topPanel.add(new JLabel("지점 검색 : "));
        topPanel.add(branchSearchField);

        String[] equipmentNames = {"구명조끼", "수영복(여)", "수영복(남)", "스노클링", "수경", "선글라스",
                "도넛튜브", "파도보호대", "막대기튜브", "샌들", "모자", "무릎보호대", "수모", "귀마개"};
        equipmentNameComboBox = new JComboBox<>(equipmentNames);
        topPanel.add(new JLabel("장비명: "));
        topPanel.add(equipmentNameComboBox);

        String[] sizes = {"S", "M", "L", "XL", "Free Size"};
        sizeComboBox = new JComboBox<>(sizes);
        topPanel.add(new JLabel("사이즈: "));
        topPanel.add(sizeComboBox);

        JButton searchButton = new JButton("검색");
        JButton modifyQuantityButton = new JButton("수량 변경"); // 추가
        topPanel.add(searchButton);
        topPanel.add(modifyQuantityButton); // 추가

        searchButton.addActionListener(e -> {
            try {
                showAllEquipmentData(db);
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });

        modifyQuantityButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showModifyQuantityDialog(frame, db); // 수정
            }
        });

        panel.add(topPanel, BorderLayout.NORTH);

        String[] columns = {"장비번호", "장비명", "사이즈", "수량", "대여료", "직원아이디"};
        originalTableModel = new DefaultTableModel(null, columns);
        table = new JTable(originalTableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        frame.getContentPane().add(panel);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);

        frame.setVisible(true);
    }

    private static void showAllEquipmentData(DBConnector db) throws SQLException {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        String selectedEquipmentName = "전체".equals(equipmentNameComboBox.getSelectedItem())
                ? null
                : (String) equipmentNameComboBox.getSelectedItem();

        String selectedSize = "전체".equals(sizeComboBox.getSelectedItem())
                ? null
                : (String) sizeComboBox.getSelectedItem();

        String selectedBranch = branchSearchField.getText();

        List<Object[]> resultList = db.sqlRun_Equipment(selectedEquipmentName, selectedSize, selectedBranch);

        for (Object[] row : resultList) {
            model.addRow(new Object[]{(String) row[0], (String) row[1], (String) row[2], (int) row[3], (int) row[4], (String) row[5]});
        }
    }

    private static void showModifyQuantityDialog(JFrame parentFrame, DBConnector db) {
        JDialog dialog = new JDialog(parentFrame, "수량 변경", true);
        dialog.setSize(200, 120); // 대화 상자 크기 조절
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        JPanel dialogPanel = new JPanel(new BorderLayout());

        JTextField quantityTextField = new JTextField(10);
        JButton confirmButton = new JButton("확인");
        JButton cancelButton = new JButton("취소");

        int selectedRow = table.getSelectedRow(); // 클릭한 행을 가져옴
        
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	if (selectedRow != -1) { 
            		String equipmentNumber = (String)table.getValueAt(selectedRow, 0); // 선택한 행의 장비번호 값
            		int quantity = Integer.parseInt(quantityTextField.getText()); // 입력한 수량
            		db.callable_updateEquipmentQuantity(equipmentNumber, quantity);
            	}
                dialog.dispose();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose(); 
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);

        dialogPanel.add(quantityTextField, BorderLayout.NORTH);
        dialogPanel.add(buttonPanel, BorderLayout.CENTER);

        dialog.getContentPane().add(dialogPanel);

        
        Dimension parentSize = parentFrame.getSize();
        Dimension dialogSize = dialog.getSize();
        dialog.setLocation(
            parentFrame.getX() + (parentSize.width - dialogSize.width) / 2,
            parentFrame.getY() + (parentSize.height - dialogSize.height) / 2
        );

        dialog.setVisible(true);
    }


    public static void main(String[] args) {
        DBConnector db = new DBConnector();
        db.DB_load();
        SwingUtilities.invokeLater(() -> showEquipmentUI(db));
    }
}
