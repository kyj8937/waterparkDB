package WPDB;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class DiscountUI {
    private static JTable table;
    private static DefaultTableModel tableModel;
    private static JTextField percentField;
    private static JLabel percentLabel;

    public static void main(String[] args) {
        DBConnector db = new DBConnector();
        db.DB_load();
        SwingUtilities.invokeLater(() -> showDiscountUI(db));
    }

    public static void showDiscountUI(DBConnector db) {
        JFrame frame = new JFrame("할인 혜택 정보");
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JPanel searchPanel = new JPanel(new FlowLayout());

        percentLabel = new JLabel("%");
        percentField = new JTextField(5);

        JButton searchButton = new JButton("검색");
        searchButton.addActionListener(e -> {
            try {
                String percentText = percentField.getText();
                loadDiscountData(db, percentText);
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });

        searchPanel.add(new JLabel("할인률"));
        searchPanel.add(percentField);
        searchPanel.add(percentLabel);
        searchPanel.add(searchButton);

        String[] columns = {"지점명", "카드회사명", "할인율", "할인된 종일권(대인)", "할인된 종일권(소인)", "할인된 오후권(대인)", "할인된 오후권(소인)"};
        tableModel = new DefaultTableModel(null, columns);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        frame.getContentPane().add(panel);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);

        frame.setVisible(true);
    }

    private static void loadDiscountData(DBConnector db, String percent) throws SQLException {
        int discountPercent;
        try {
            discountPercent = Integer.parseInt(percent);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "할인률을 정확히 입력하세요.", "입력 오류", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (discountPercent < 0 || discountPercent > 100) {
            JOptionPane.showMessageDialog(null, "할인률은 0%에서 100% 사이의 값이어야 합니다.", "입력 오류", JOptionPane.ERROR_MESSAGE);
            return;
        }

      
        clearTableData();

        List<Object[]> resultList = db.sqlRun_Discount(String.valueOf(discountPercent));

        for (Object[] row : resultList) {
            addDiscountData((String) row[0], (String) row[1], (int) row[2], (int) row[3], (int) row[4], (int) row[5], (int) row[6]);
        }
    }

    private static void clearTableData() {
      
        tableModel.setRowCount(0);
    }

    
    private static void addDiscountData(String branch, String cardCompany, int discountRate,
                                        int fullDayAdult, int fullDayChild,
                                        int afternoonAdult, int afternoonChild) {
        Vector<Object> row = new Vector<>();
        row.add(branch);
        row.add(cardCompany);
        row.add(discountRate);
        row.add(fullDayAdult);
        row.add(fullDayChild);
        row.add(afternoonAdult);
        row.add(afternoonChild);
        tableModel.addRow(row);
    }
}

