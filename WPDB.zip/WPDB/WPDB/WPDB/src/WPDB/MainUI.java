package WPDB;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class MainUI {
    private static JLabel label;
	private static DBConnector db = new DBConnector();

    public static void main(String[] args) {
    	db.DB_load();
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("워터파크 관리 시스템");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        label = new JLabel("워터파크 관리 시스템");
        label.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel panel = new JPanel(null);

        panel.add(label);

        JButton button1 = createButton("매출 검색", 400, 320, 150, 30);
        panel.add(button1);

        JButton button2 = createButton("장비 검색", 400, 360, 150, 30);
        panel.add(button2);

        JButton button3 = createButton("할인 혜택 검색", 400, 400, 150, 30);
        panel.add(button3);

        JButton button4 = createButton("놀이기구 검색", 400, 440, 150, 30);
        panel.add(button4);

        frame.getContentPane().add(panel, BorderLayout.CENTER);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);

        frame.setVisible(true);

        setFontSize(50);
        setLabelBounds(200, 100, 580, 50);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
					SalesUI.showSalesUI(db);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EquipmentUI.showEquipmentUI(db);
            }
        });

        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DiscountUI.showDiscountUI(db);
            }
        });

        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AttractionUI.showAttractionUI(db);
            }
        });
    }

    private static void setFontSize(int size) {
        Font font = new Font("맑은 고딕", Font.PLAIN, size);
        label.setFont(font);
    }

    private static void setLabelBounds(int x, int y, int width, int height) {
        label.setBounds(x, y, width, height);
    }

    private static JButton createButton(String text, int x, int y, int width, int height) {
        JButton button = new JButton(text);
        button.setBounds(x, y, width, height);
        button.addActionListener(new ButtonActionListener());
        return button;
    }

    private static class ButtonActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton button = (JButton) e.getSource();
            String buttonText = button.getText();
        }
    }
}
