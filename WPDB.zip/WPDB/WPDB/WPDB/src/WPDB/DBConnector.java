package WPDB;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;

public class DBConnector {
	   Connection con = null;
	   String url = "jdbc:oracle:thin:@localhost:1521:XE";
	   String id = "DBTEAM";      
	   String password = "1234";
	   
	   public DBConnector() {
	   }
	   
	   public void DB_load() {
		   try {
			   Class.forName("oracle.jdbc.driver.OracleDriver");
			   System.out.println("드라이버 적재 성공");
		   } catch (ClassNotFoundException e) { 
			   System.out.println("No Driver."); 
		   }  
	   }
	   public void DB_Connect() {
		   try {
			   con = DriverManager.getConnection(url, id, password);
			   System.out.println("DB 연결 성공");
		   } catch (SQLException e) {         
			   System.out.println("Connection Fail");      
		   }
	   }
	   
	   public List<Object[]> sqlRun_Equipment(String equipment, String size, String branch) throws SQLException {
		   List<Object[]> resultList = new ArrayList<>();

		   String query =
				   "select \r\n"
				 + "    장비번호, \r\n"
		   		 + "    장비명, \r\n"
		   		 + "    사이즈, \r\n"
		   		 + "    수량, \r\n"
		   		 + "    대여료, \r\n"
		   		 + "    장비.직원아이디\r\n"
		   		 + "from \r\n"
		   		 + "    장비, 직원\r\n"
		   		 + "where \r\n"
		   		 + "    장비.직원아이디 = 직원.직원아이디\r\n"
		   		 + "    and 장비.장비명 = ?\r\n"
		   		 + "    and 장비.사이즈 = ?\r\n"
		   		 + "    and 장비.직원아이디 in\r\n"
		   		 + "        (\r\n"
		   		 + "            select 직원.직원아이디\r\n"
		   		 + "            from 직원\r\n"
		   		 + "            where 직원.지점명 = ?\r\n"
		   		 + "        )";
				   
		   PreparedStatement pstmt = null;
		   try { 
			   DB_Connect();
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, equipment);       		// 장비이름 설정
			   pstmt.setString(2, size);					// 장비 사이즈 설정
			   pstmt.setString(3, branch);  // 지점 설정
			   
			   ResultSet rs = pstmt.executeQuery();
			   
			   while(rs.next()){
				   Object[] row = new Object[6];
				   
				   row[0] = rs.getString("장비번호");
				   row[1] = rs.getString("장비명");
				   row[2] = rs.getString("사이즈");
				   row[3] = rs.getInt("수량");
				   row[4] = rs.getInt("대여료");
				   row[5] = rs.getString("직원아이디");
				   
				   resultList.add(row);
			   }
			   pstmt.close();
			   con.close();
			   
		       return resultList;
		   } catch (SQLException e) { 
			   e.printStackTrace();
			   return null;
		   } finally {   
			    
		   }
	   }
	   
	   public List<Object[]> sqlRun_AttractionCheckPeriod(String branch) throws SQLException {
		    List<Object[]> resultList = new ArrayList<>();

		    String selectQuery =
		            "SELECT " +
		                    "    기구명, " +
		                    "    CASE " +
		                    "        WHEN floor(sysdate - 점검일자) > 90 THEN 운휴일자 " +
		                    "        ELSE NULL " +
		                    "    END AS 운휴일자, " +
		                    "    floor(sysdate - 점검일자) AS 경과일자, " +
		                    "    지점명, " +
		                    "    이용객수, " +
		                    "    직원아이디 " +
		                    "FROM " +
		                    "    놀이기구 " +
		                    "WHERE " +
		                    "    지점명 = ?";

		    try {
		        DB_Connect();

		        PreparedStatement selectPstmt = con.prepareStatement(selectQuery);
		        selectPstmt.setString(1, branch);

		        ResultSet rs = selectPstmt.executeQuery();

		        while (rs.next()) {
		            Object[] row = new Object[6];

		            row[0] = rs.getString("기구명");
		            row[1] = rs.getDate("운휴일자"); // 운휴일자 열로 변경
		            row[2] = rs.getInt("경과일자");
		            row[3] = rs.getString("지점명");
		            row[4] = rs.getInt("이용객수");
		            row[5] = rs.getString("직원아이디");

		            resultList.add(row);
		        }

		        return resultList;
		    } catch (SQLException e) {
		        e.printStackTrace();
		        return null;
		    } finally {
		        try {
		            if (con != null) con.close();
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
		    }
		}

	   public void updateAttractionCheckPeriod(String branch) throws SQLException {
		    String updateQuery = "UPDATE 놀이기구 SET 운휴일자 = sysdate WHERE floor(sysdate - 점검일자) > 90 AND 지점명 = '" + branch + "'";

		    try {
		        DB_Connect();

		        Statement updateStmt = con.createStatement();
		        updateStmt.executeUpdate(updateQuery);

		        updateStmt.close();
		    } catch (SQLException e) {
		        e.printStackTrace();
		    } finally {
		        try {
		            if (con != null) con.close();
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
		    }
		}

		
		public static void updateAttractionRestDays(DBConnector db, String branch) throws SQLException {
	        try (Connection con = DriverManager.getConnection(db.url, db.id, db.password)) {
	            // 자동 커밋 비활성화
	            con.setAutoCommit(false);
	            
	            try (CallableStatement stmt = con.prepareCall("{call 점검기간_확인(?, 90, sysdate)}")) {
	                
	                stmt.setString(1, branch);
	                
	                stmt.execute();
            
	                con.commit();

	            } catch (SQLException e) {
	                
	                con.rollback();
	                throw e; 
	            } finally {
	                // 자동 커밋 활성화
	                con.setAutoCommit(true);
	            }
	        }
	    }

		
	   
	   public List<Object[]> sqlRun_Sales(String month) throws SQLException {
		   List<Object[]> resultList = new ArrayList<>();

		   String query =
				   "select \r\n"
				   + "    매출.지점명,\r\n"
				   + "    sum(매출.총액) as 총액,\r\n"
				   + "    매출.관리자아이디\r\n"
				   + "from \r\n"
				   + "    매출\r\n"
				   + "where\r\n"
				   + "    extract(month from 날짜) = " + month + "\r\n"
				   + "group by \r\n"
				   + "    매출.지점명, 매출.관리자아이디\r\n"
				   + "order by \r\n"
				   + "    총액 desc";
				   
		   Statement stmt = null;
		   try { 
			   DB_Connect();
			   stmt = con.createStatement();
			   ResultSet rs = stmt.executeQuery(query);
			   
			   // List에 결과를 모두 저장해서 List를 반환
			   while(rs.next()){
				   Object[] row = new Object[3];
				   
				   row[0] = rs.getString("지점명");
				   row[1] = rs.getInt("총액");
				   row[2] = rs.getString("관리자아이디");
				   
				   resultList.add(row);
			   }
			   
			   stmt.close();
			   con.close();
			   
			   return resultList;
		   } catch (SQLException e) { 
			   e.printStackTrace();
			   return null;
		   } finally {   
		   }
	   }
	   
	   public List<Object[]> sqlRun_Discount(String discountRate) throws SQLException {
		   List<Object[]> resultList = new ArrayList<>();

		   String query =
				    "WITH 할인 AS (" +
				    "    SELECT " +
				    "        지점.지점명, " +
				    "        카드사.카드회사명, " +
				    "        TO_NUMBER(REGEXP_SUBSTR(할인혜택, '\\d+')) AS 할인율 " +
				    "    FROM " +
				    "        카드사, 지점 " +
				    "    WHERE " +
				    "        지점.지점명 = 카드사.지점명" +
				    ")" +
				    "SELECT " +
				    "    지점.지점명, " +
				    "    할인.카드회사명," +
				    "    할인.할인율," +
				    "    (종일권_대인 * (100 - 할인.할인율) / 100) AS 종일권대인_할인," +
				    "    (종일권_소인 * (100 - 할인.할인율) / 100) AS 종일권소인_할인," +
				    "    (오후권_대인 * (100 - 할인.할인율) / 100) AS 오후권대인_할인," +
				    "    (오후권_소인 * (100 - 할인.할인율) / 100) AS 오후권소인_할인 " +
				    "FROM " +
				    "    지점, 할인 " +
				    "WHERE " +
				    "    지점.지점명 = 할인.지점명 " +
				    "    AND 할인.할인율 >= " + discountRate;

				   
		   Statement stmt = null;
		   try { 
			   DB_Connect();
			   stmt = con.createStatement();
		       //return stmt.executeQuery(query); // 실행결과 반환(ResultSet 타입)
		       ResultSet rs = stmt.executeQuery(query);
		       
		       while(rs.next()){
				   Object[] row = new Object[7];
				   
				   row[0] = rs.getString("지점명");
				   row[1] = rs.getString("카드회사명");
				   row[2] = rs.getInt("할인율");
				   row[3] = rs.getInt("종일권대인_할인");
				   row[4] = rs.getInt("종일권소인_할인");
				   row[5] = rs.getInt("오후권대인_할인");
				   row[6] = rs.getInt("오후권소인_할인");
				   
				   resultList.add(row);
			   }
		       
		       stmt.close();
			   con.close();
			   return resultList;
		   } catch (SQLException e) { 
			   e.printStackTrace();
			   return null;
		   } finally {   
		   }
	   }
	   public void callable_updateEquipmentQuantity(String equipmentNumber, int quantity) {
		   
		   try { DB_Connect();
			   CallableStatement cstmt = con.prepareCall("{call 장비수량_갱신(?, ?)}");
			   cstmt.setString(1, equipmentNumber);
			   cstmt.setInt(2, quantity);
			   cstmt.executeQuery();
			   
			   cstmt.close();    
			   con.close(); 
		   } catch (SQLException e) { 
			   e.printStackTrace(); 
		   }
	   }

	public static void main(String arg[]) throws SQLException {
		
	}
}