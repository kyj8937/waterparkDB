package WPDB;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Vector;

public class AttractionUI {
    private static JTable table;
    private static DefaultTableModel tableModel;
    private static JTextField branchSearchField;

    public static void main(String[] args) {
        // SwingUtilities.invokeLater(() -> showAttractionUI());
    }

    public static void showAttractionUI(DBConnector db) {
        JFrame frame = new JFrame("놀이기구 점검 날짜");
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JPanel searchPanel = new JPanel(new FlowLayout());

        branchSearchField = new JTextField(15);
        searchPanel.add(new JLabel("지점 검색 : "));
        searchPanel.add(branchSearchField);

        JButton searchButton = new JButton("검색");
        searchButton.addActionListener(e -> {
            try {
                searchAttractionData(db, branchSearchField.getText());
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });
        searchPanel.add(searchButton);
       
        JButton updateButton = new JButton("운휴날짜 업데이트");
        updateButton.addActionListener(e -> {
            try {
                updateAttractionRestDays(db, branchSearchField.getText());
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });
        searchPanel.add(updateButton);

        String[] columns = {"기구명", "운휴일자", "경과일", "지점명", "이용객수", "직원아이디"};

        tableModel = new DefaultTableModel(null, columns);

        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);

        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        frame.getContentPane().add(panel);

        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);

        frame.setVisible(true);
    }

    private static void updateAttractionRestDays(DBConnector db, String branch) throws SQLException {
        db.updateAttractionCheckPeriod(branch);
        searchAttractionData(db, branch);
    }



    private static void searchAttractionData(DBConnector db, String branchSearchText) throws SQLException {
        List<Object[]> resultList = new ArrayList<>();

        tableModel.setRowCount(0);

        
        resultList = db.sqlRun_AttractionCheckPeriod(branchSearchText);

        for (Object[] row : resultList) {
            addAttractionData((String) row[0], (int) row[2], (Date) row[1], (String) row[3], (int) row[4], (String) row[5]);
        }
    }

    private static void addAttractionData(String attraction, int daysSinceLastCheck, Date checkDate, String branch, int visitorCount, String employeeId) {
        Vector<Object> row = new Vector<>();
        row.add(attraction);
        row.add(checkDate);
        row.add(daysSinceLastCheck);  
        row.add(branch);
        row.add(visitorCount);
        row.add(employeeId);
        tableModel.addRow(row);
    }
}
